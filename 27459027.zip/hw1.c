#include <stdio.h>
#include "hw1.h"



//int main(int argc,char* argv[]){
  //printf("this is probably the worst skeleton code ever\n");
  //return 0;
  

	static void I_have_written(){
	printf ( "tgupta22");
}

	static void that_you_needed(){
	}

	static void and_which() {
	}

	static int  the_code[3] = {2,1,3};

	

	int main(int argc, char* argv[]){


		I_have_written();
		that_you_needed();
		and_which();

		static int to_compile = 2213;

		static int has_a_bunch_of = 2220;

		static int ridiculous = 2221;
		static double symbols;

		to_compile++;

		has_a_bunch_of++;

		ridiculous++;

		symbols++;
		the_code[1] = 2;
		Forgive_me();

		and_so_varied();



		return 0;
	}

